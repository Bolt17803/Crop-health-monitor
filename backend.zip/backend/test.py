# Classification-api
#import classification_api as classifier
#from PIL import Image
#
#img = Image.open("t10.jpg")
#print(classifier.predict(img))

#Segmentation-api
import segmentation_api as segmentor


