import React from "react";

export default function About(){
    return (
        <div className="page--about" id="about">
            <div className="page--about--container">
                <h1>Made By:</h1>
                <h2>Gaddey Hemanth Chowdary & Anumula Chaitanya Sai</h2>
                {/* <h2>Anumula Chaitanya Sai</h2> */}
                {/* <p>@ idhi maa adda nuvveedraa naa ***</p> */}
            </div>
        </div>
    )
}